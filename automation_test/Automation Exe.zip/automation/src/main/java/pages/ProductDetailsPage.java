package pages;

import org.openqa.selenium.WebDriver;

public class ProductDetailsPage extends PageBase {

	public ProductDetailsPage(WebDriver driver) {
		super(driver);
	}
	
	

}
