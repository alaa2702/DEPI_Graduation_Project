package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CartPage extends PageBase {

	public CartPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(css = "div.col-sm-6 > a")
	WebElement checkOutBtn;

	@FindBy(css = "tr.cart_menu td.description")
	WebElement descriptionTitle;

	@FindBy(xpath = "//td[@class='cart_description']/h4/a")
	List<WebElement> productNames;

	@FindBy(xpath = "//td[@class='cart_price']/p")
	List<WebElement> productPrices;

	@FindBy(className = "disabled")
	List<WebElement> productQuantities;

	@FindBy(className = "cart_total_price")
	List<WebElement> productTotalPrices;

	@FindBy(className = "cart_quantity_delete")
	List<WebElement> deleteBtn;

	// ======= Utility Methods =======
	public List<String> getAllProductNames() {
		List<String> names = new ArrayList<>();
		for (WebElement name : productNames) {
			names.add(name.getText());
		}
		return names;
	}

	public List<String> getAllProductPrices() {
		List<String> prices = new ArrayList<>();
		for (WebElement price : productPrices) {
			prices.add(price.getText());
		}
		return prices;
	}

	public String ProductQuantitiesTxt(int index) {
		if (index >= 0 && index < productQuantities.size()) {
			return productQuantities.get(index).getText();
		} else {
			return null;
		}
	}

	public String ProductTotalPricesTxt(int index) {
		if (index >= 0 && index < productTotalPrices.size()) {
			return productTotalPrices.get(index).getText();
		} else {
			return null;
		}
	}
	public void DeleteProudctByIndex(int index) {
		if (index >= 0 && index < deleteBtn.size()) {
			deleteBtn.get(index).click();
		}
	}
	

}